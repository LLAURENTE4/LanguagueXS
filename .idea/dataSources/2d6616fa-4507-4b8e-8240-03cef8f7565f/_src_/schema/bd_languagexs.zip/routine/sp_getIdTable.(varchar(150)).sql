CREATE PROCEDURE sp_getIdTable(IN table_name VARCHAR(150), OUT table_id INT)
  BEGIN
	DECLARE rowcount int default 0;
    
	SELECT count(*),max(id)
    INTO rowcount,table_id
    FROM tables
    WHERE name=table_name;   
	
    if rowcount=0 or isnull(rowcount) then    
		set table_id=1;
        
		INSERT INTO tables VALUES(table_name,table_id);
	
	else
		set table_id=table_id+1;
        
		UPDATE tables
			SET id=table_id
		WHERE name=table_name;
	end if;
END;
